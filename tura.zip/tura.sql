-- --------------------------------------------------------
-- Hoszt:                        127.0.0.1
-- Szerver verzió:               8.0.32 - MySQL Community Server - GPL
-- Szerver OS:                   Win64
-- HeidiSQL Verzió:              12.4.0.6659
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Adatbázis struktúra mentése a tura.
CREATE DATABASE IF NOT EXISTS `tura` /*!40100 DEFAULT CHARACTER SET utf8mb3 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `tura`;

-- Struktúra mentése tábla tura. esemeny
CREATE TABLE IF NOT EXISTS `esemeny` (
  `id` int NOT NULL AUTO_INCREMENT,
  `esemenynev` varchar(355) DEFAULT NULL,
  `esemeny_datuma` datetime DEFAULT NULL,
  `esemeny_leiras` text,
  `tag_id` int DEFAULT NULL,
  `esemeny_eng` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_esemeny_tag1_idx` (`tag_id`),
  CONSTRAINT `fk_esemeny_tag1` FOREIGN KEY (`tag_id`) REFERENCES `tag` (`tid`)
) ENGINE=InnoDB AUTO_INCREMENT=137 DEFAULT CHARSET=utf8mb3;

-- Tábla adatainak mentése tura.esemeny: ~6 rows (hozzávetőleg)
INSERT IGNORE INTO `esemeny` (`id`, `esemenynev`, `esemeny_datuma`, `esemeny_leiras`, `tag_id`, `esemeny_eng`) VALUES
	(1, 'vezetéstechnikai tréning', '2023-04-30 10:00:00', 'Az időpont: április 29-30.\r\nHelyszíne : Sződliget\r\nEz most egy nagyon izgalmas, és egyelőre vissza nem térő alkalom arra, hogy bárki a csapatból egy olyan tréningen vegyen részt, amely után nagyobb biztonsággal tud motorozni, meg tudja tapasztalni, hogyan lehet elkerülni egy balesetet és a két napos tréninget követően akár  tudatosabban irányíthatja majd a motorját vészhelyzetben is. ', 4, 1),
	(2, 'Fóti felvonulás', '2023-05-01 10:00:00', 'Fóton május 1-en terveznek egy veterán autós, és motoros felvonulást amire szeretettel várnak minket. ', 3, 1),
	(3, 'Őrségi túra', '2023-05-24 08:00:00', 'Idén ismét megrendezzük a hagyományos őrségi szezonindító túrát. ', 2, 1),
	(41, 'cigánykerék', '2023-05-31 15:15:00', 'kisebbségi fordulat', 69, 1),
	(71, 'megszervezem', '2023-06-11 16:11:00', 'tesztszervezés', 68, 1),
	(135, 'tiniint', '2023-06-09 21:01:00', 'nulla lesz?', 68, 0),
	(136, 'engedely', '2023-07-09 18:09:00', 'T Ö R Ö L T  E S E M É NY !!!!', 68, 1);

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
